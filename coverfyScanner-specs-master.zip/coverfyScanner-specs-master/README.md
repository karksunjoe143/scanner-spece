# coverfyScanner-specs
